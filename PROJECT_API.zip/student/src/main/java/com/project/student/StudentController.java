package com.project.student;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transaction;

import org.springframework.web.bind.annotation.RestController;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@CrossOrigin("http://localhost:8080")
public class StudentController {

	@Autowired
	SessionFactory factory;

	List<Student> arrayList= null;

	StudentController(){

	}
	@GetMapping ("GetStudent")
	List<Student> allStudents() {
		Session s = factory.openSession();
		arrayList = s.createCriteria(Student.class).list();
		return arrayList;
	}

	@GetMapping("student/{rno}")
	Student getstudent(@PathVariable int rno) {
		Session s=factory.openSession()	;
		Student stu=s.load(Student.class, rno);
		return stu;


	}

	@PostMapping("addstudent")
	List<Student> addStudent(@RequestBody Student student) {
		Session s=factory.openSession();
		org.hibernate.Transaction t=s.beginTransaction();
		s.save(student);
		t.commit();
		List<Student> list=allStudents();
		return list;
	}


	@DeleteMapping("cc/{rno}")
	List<Student> deleteStudent(@PathVariable int rno) {
		Session s=factory.openSession();
		Student stu=s.load(Student.class, rno);
		org.hibernate.Transaction t=s.beginTransaction();
		s.delete(stu);
		t.commit();
		List<Student> list=allStudents();
		return list;
		
	}
	@PutMapping("update")
	List<Student> updateStudent(@RequestBody Student student) {
		Session s=factory.openSession();
		org.hibernate.Transaction t=s.beginTransaction();
		s.saveOrUpdate(student);
		t.commit();
		List<Student> list=allStudents();
		return list;
	}

}
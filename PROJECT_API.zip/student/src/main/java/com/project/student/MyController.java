package com.project.student;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {
	@RequestMapping("apicall")
	public String apicall() {
		return "apicall";
	}
	@RequestMapping("testcall")
	public ModelAndView test() {
		ArrayList<String>arrayList=new ArrayList<>();
		arrayList.add("vaibhu");
		arrayList.add("vivek");
		arrayList.add("panuu");
		ModelAndView modelandview=new ModelAndView("test","data",arrayList);
		return modelandview;
	}

}

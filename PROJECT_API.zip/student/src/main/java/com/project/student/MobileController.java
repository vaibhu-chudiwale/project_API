package com.project.student;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MobileController {
	
	@Autowired
	SessionFactory factory;
	
	@RequestMapping("getmobiles")
	public List<Mobile> getMobiles(){
		List<Mobile> arrList=factory.openSession().createCriteria(Mobile.class).list();
		return arrList;
	}
	
	
	

}

package mobilecontroller;

import java.util.ArrayList;
import java.util.TreeSet;

public class SortPhoneTest {
	public static void main(String[] args) {
		Mobile mob1=new Mobile(10,8);
		Mobile mob2=new Mobile(23,10);
		Mobile mob3=new Mobile(23,25);
		Mobile mob4=new Mobile(25,65);
		
		ArrayList<Mobile> al=new ArrayList<>();
		
		al.add(mob1);
		al.add(mob2);
		al.add(mob3);
		al.add(mob4);
		
		TreeSet<Mobile> treeSet=new TreeSet<Mobile>(new SortOnPrice());
		
		for (Mobile mobile : al) {
			int price=mobile.price;
			if (price>=15 && price<=30);
			treeSet.add(mobile);
			
		}
		System.out.println(treeSet);
	}

}
